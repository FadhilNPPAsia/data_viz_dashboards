from flask import Flask, render_template
app = Flask(__name__)

@app.route('/')
def home_page():
    return render_template('home.html')

@app.route('/dashboard_1')
def dashboard_1_page():
    return render_template('dashboard_1.html')

@app.route('/dashboard_2')
def dashboard_2_page():
    return render_template('dashboard_2.html')

